
for i in range(255):
    print(str(i) + ": " + str((255-i)) +",")
